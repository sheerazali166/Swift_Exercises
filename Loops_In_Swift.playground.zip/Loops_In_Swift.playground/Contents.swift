import UIKit

var greeting = "Hello, playground"

print("Chocolaty Kinza sheikh")

for dice in 1...6{
    print("Roll a \(dice)")
}


//var firstDice = Int.random(in: 1...6)
//
//var secondDice = Int.random(in: 1...6)
//
//while firstDice != secondDice{
//
//    firstDice = Int.random(in: 1...6)
//
//    secondDice = Int.random(in: 1...6)
//}

print("You rolled a double \(firstDice).")

var firstDice = 0

var secondDice = 0

repeat{
    
    firstDice = Int.random(in: 1...6)
    
    secondDice = Int.random(in: 1...6)
    
} while firstDice != secondDice
    print("You rolled a double \(firstDice).")


print("chocolate kinza sheikh")





