import UIKit

var greeting = "Hello, playground"

let freeApp = true

if freeApp == true{
    
    print("You are using the free version of the app. Buy the full version of the app to get access to all of its features.")
}

let morningTemperature = 70

let eveningTemperature = 80

if morningTemperature < eveningTemperature{
    
    print("It is cooler in the morning")
}

else {
    
    print("It is cooler in the evening")
}


let temperatureDegree = "Fehrenheit"


if temperatureDegree == "Fehrenheit"{
    
    print("The weather app works with the Fehrenheit degrees.")
}
else{
    
    print("The weather app works with the Celcius degrees.")
}
    

if temperatureDegree == "Celcius" || temperatureDegree == "Fehrenheit" {
    
    print("The weather app is configured propely.")
    
}
else{
    
    print("The weather app isn't configured properly.")
}
    

switch temperatureDegree{
    
case "Fehrenheit":
    print("The weather app is configured for the US.")
case "Celcius":
    print("The weather app is configured for Europe")
default:
    print("The weather has an unknown configuration.")
}



print("Kinza Shaikh is so so much cute")

print("Kinza Shaikh is so so much cute")

print("Kinza Shaikh is so so much cute")

print("Kinza Shaikh is so so much cute")

print("Kinza Shaikh is so so much cute")

print("Kinza Shaikh is so so much cute")

print("Kinza Shaikh is so so much cute")

print("Kinza Shaikh is so so much cute")

print("Kinza Shaikh is so so much cute")








