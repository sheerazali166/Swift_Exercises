import UIKit

print("Kinza Shaikh is so so much chocolaty")

print("Kinza Shaikh is so so much chocolaty")

print("Kinza Shaikh is so so much chocolaty")

print("Kinza Shaikh is so so much chocolaty")

print("Kinza Shaikh is so so much chocolaty")

print("Kinza Shaikh is so so much chocolaty")



var greeting = "Hello, playground"

let day = "Monday"

let dailyTempreture = 75

print("Today is \(day) Rise and shine!")

print("The temprature on \(day) is \(dailyTempreture)F.")

var temperatue = 70

print("The temperature in the monday on \(day) is \(temperatue)F.")

temperatue = 80

print("The temperature in the evening on \(day) is \(temperatue)F.")

let weeklyTemperature = 75

temperatue = weeklyTemperature

print("The average temperature this weak is \(temperatue).")





print("Kinza Shaikh is so so much cute")

print("Kinza Shaikh is so so much cute")

print("Kinza Shaikh is so so much cute")

print("Kinza Shaikh is so so much cute")

print("Kinza Shaikh is so so much cute")

print("Kinza Shaikh is so so much cute")

